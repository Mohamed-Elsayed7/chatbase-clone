import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/types/supabase"
import { getAdminSupabase } from "@/lib/usage"

export const dynamic = "force-dynamic"

export async function GET() {
  try {
    // 1) Identify the caller via auth cookies
    const cookieStore = cookies()
    const userClient = createRouteHandlerClient<Database>({ cookies: () => cookieStore })
    const { data: { user }, error: authErr } = await userClient.auth.getUser()
    if (authErr || !user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    // 2) Use service client for flexible querying (bypasses RLS safely on server)
    const admin = getAdminSupabase()

    // Check superadmin
    const { data: profile, error: profErr } = await admin
    .from("profiles")
    .select("id, is_superadmin")
    .eq("id", user.id)

    console.log("AUTH user.id =", user.id)
    console.log("Profile query result =", profile, "error =", profErr)
    if (profErr) throw profErr

    // 3) Build query
    let chatbots: Array<{
      id: number
      name: string
      description: string | null
      user_id: string
      organization_id: number | null
      created_at: string
      brand_name: string | null
      widget_theme: string | null
      widget_primary_color: string | null
      website_url: string | null
    }> = []

    if (profile?.is_superadmin) {
      // Superadmin sees everything
      const { data, error } = await admin
        .from("chatbots")
        .select("id,name,description,user_id,organization_id,created_at,brand_name,widget_theme,widget_primary_color,website_url")
        .order("created_at", { ascending: false })
      if (error) throw error
      chatbots = data ?? []
    } else {
      // Normal user: own bots or org bots
      const { data: memberships, error: memErr } = await admin
        .from("organization_members")
        .select("organization_id")
        .eq("user_id", user.id)
      if (memErr) throw memErr

      const orgIds = (memberships ?? []).map(m => m.organization_id).filter(Boolean) as number[]

      const { data, error } = await admin
        .from("chatbots")
        .select("id,name,description,user_id,organization_id,created_at,brand_name,widget_theme,widget_primary_color,website_url")
        .or([
          `user_id.eq.${user.id}`,
          orgIds.length ? `organization_id.in.(${orgIds.join(",")})` : ""
        ].filter(Boolean).join(","))
        .order("created_at", { ascending: false })
      if (error) throw error
      chatbots = data ?? []
    }

    // 4) Attach organization name
    const orgIds = Array.from(new Set(chatbots.map(c => c.organization_id).filter(Boolean))) as number[]
    let orgMap: Record<number, string> = {}
    if (orgIds.length) {
      const { data: orgs, error: orgErr } = await admin
        .from("organizations")
        .select("id,name")
        .in("id", orgIds)
      if (orgErr) throw orgErr
      orgMap = Object.fromEntries((orgs ?? []).map(o => [o.id, o.name]))
    }

    const result = chatbots.map(c => ({
      ...c,
      organization_name: c.organization_id ? (orgMap[c.organization_id] ?? null) : null,
    }))

    return NextResponse.json({ chatbots: result })
  } catch (err: any) {
    console.error("CHATBOTS GET ERROR:", err?.message || err)
    return NextResponse.json({ error: err?.message || "Server error" }, { status: 500 })
  }
}
