import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { getAdminSupabase } from "@/lib/usage"
import type { Database } from "@/types/supabase"

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const cookieStore = cookies()
    const userClient = createRouteHandlerClient<Database>({
      cookies: () => cookieStore,
    })
    console.log("cookies sent to API:", cookieStore.getAll())
    const { data: { user }, error: authErr } = await userClient.auth.getUser()
    if (authErr || !user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }

    const admin = getAdminSupabase()
    const chatbotId = Number(params.id)

    // 1. Check if user is superadmin
    const { data: profile } = await admin
      .from("profiles")
      .select("is_superadmin")
      .eq("id", user.id)
      .maybeSingle()

    let query = admin
      .from("chatbots")
      .select("*, organizations(name)")
      .eq("id", chatbotId)

    if (!profile?.is_superadmin) {
      // Restrict: must own or belong to org
      query = query.or(`user_id.eq.${user.id}`)
    }

    const { data: chatbot, error } = await query.maybeSingle()
    if (error) throw error

    if (!chatbot) {
      return NextResponse.json({ error: "Not found" }, { status: 404 })
    }

    return NextResponse.json(chatbot)
  } catch (err: any) {
    console.error("CHATBOT DETAIL ERROR:", err.message || err)
    return NextResponse.json(
      { error: err.message || "Server error" },
      { status: 500 }
    )
  }
}
